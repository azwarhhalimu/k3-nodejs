const HomeMdl = require("../model/HomeMdl");
const RambuTbl = require("../model/RambuTbl");
const TipsTbl = require("../model/TipsTbl");

class PublicController {
    async getRambu(req, res) {
        const data = await new RambuTbl().getAll();
        res.json({ data: data })
    }
    async getTips(req, res) {
        const data = await new TipsTbl().getAll();
        res.json({ data: data })
    }
    async getHome(req, res) {
        const artikel = await HomeMdl.dasbhard();
        const pengertian = await HomeMdl.pengertian();
        const peralatan = await HomeMdl.peralatan();

        res.send({
            artikel: artikel,
            pengertian: pengertian,
            peralatan: peralatan,
        });
    }
}

module.exports = new PublicController();