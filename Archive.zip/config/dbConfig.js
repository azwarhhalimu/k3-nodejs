const dbConfing = {
    host: "localhost",
    user: 'root',
    password: "",
    database: "k3",
}
module.exports = dbConfing;