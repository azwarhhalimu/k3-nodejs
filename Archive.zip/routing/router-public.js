const express = require("express");
const PublicController = require("../controller/PublicController");
const public_router = express.Router();

public_router.get("/rambu-rambu", PublicController.getRambu);
public_router.get("/tips", PublicController.getTips);
public_router.get("/home", PublicController.getHome);
module.exports = public_router;